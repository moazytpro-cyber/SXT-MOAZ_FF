SXT-MOAZ_FF Android APK তৈরি করার নিয়ম
======================================

এই ZIP-এ Android Studio project এবং tournament app-এর HTML ফাইল আছে।
এটি APK-এর source project; APK ফাইলটি এই পরিবেশে compile করা হয়নি।

যা লাগবে:
- কম্পিউটারে Android Studio
- Android SDK Platform 35
- JDK 17 (Android Studio সাধারণত এটি দেয়)

APK বানানোর ধাপ:
1. ZIP extract করো।
2. Android Studio খুলে Open নির্বাচন করো।
3. Extract করা SXT-MOAZ_FF_Android_Project ফোল্ডারটি নির্বাচন করো।
4. Gradle Sync শেষ হতে দাও। SDK 35 না থাকলে Android Studio-র SDK Manager থেকে install করো।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) চাপো।
6. APK সাধারণত পাওয়া যাবে:
   app/build/outputs/apk/debug/app-debug.apk

ফোনে install:
- APK ফোনে পাঠাও।
- ফাইলটি tap করে install করো।
- প্রয়োজন হলে Android Settings-এ ওই file manager/browser-এর জন্য “Install unknown apps” অনুমতি দাও।
- শুধু নিজের তৈরি/বিশ্বস্ত APK install করো।

গুরুত্বপূর্ণ:
- Admin demo PIN: 1234 (প্রথমবার ব্যবহার করার পর বদলে নিও)।
- ডেটা এই ফোনের অ্যাপেই থাকে; online sync/server নেই।
- অ্যাপটি tournament management-এর জন্য; Free Fire-এর game files বা gameplay পরিবর্তন করে না।

ফোন থেকে GitHub Actions দিয়ে APK বানানো:
1. এই ZIP extract করে সব ফাইল GitHub repository-র main branch-এ upload করো।
2. Repository-এর Actions tab খোলো।
3. "Build SXT-MOAZ_FF APK" workflow বেছে Run workflow চাপো (অথবা main branch-এ push করলে নিজে চালু হবে)।
4. Build সফল হলে workflow run-এর পেজের নিচে Artifacts থেকে SXT-MOAZ_FF-debug-apk ডাউনলোড করো।
5. ZIP artifact extract করলে app-debug.apk পাবে।
